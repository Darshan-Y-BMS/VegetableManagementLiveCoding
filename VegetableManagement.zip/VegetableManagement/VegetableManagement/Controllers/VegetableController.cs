﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using VegetableManagement.Components;
using VegetableManagement.Repositries;

namespace VegetableManagement.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VegetableController : ControllerBase
    {
        private readonly IVegetable _vegetableRepository;
        public VegetableController(IVegetable vegetableRepository)
        {
            _vegetableRepository = vegetableRepository;
        }

        [HttpGet]
        [Route("GettingAllRecord")]
        public async Task<ActionResult<IEnumerable<VegetableDetails>>> GetAllRecord()
        {
            var temp = await _vegetableRepository.GetAll();
            if (temp == null) { return NotFound(); }
            return Ok(temp);
        }
        [HttpGet]
        [Route("GettingRecordByID")]

        public async Task<ActionResult<VegetableDetails>> GetRecordByID(int id)
        {
            var temp = await _vegetableRepository.GetByID(id);
            if (temp == null) 
            { return NotFound(); }

            return Ok(temp);
        }

 


        [HttpPost]
        public async Task<ActionResult<VegetableDetails>> PostRecord(VegetableDetails vegetableDetails)
        {
            await _vegetableRepository.Post(vegetableDetails);

            return CreatedAtAction(nameof(GetAllRecord), new { id = vegetableDetails.VegetableID }, vegetableDetails);
        }

        [HttpPut]
        public async Task<ActionResult> PutRecord(int id,VegetableDetails vegetableDetails)
        {
            if (id != vegetableDetails.VegetableID)
            {
                return BadRequest();
            }
            try
            {
                await _vegetableRepository.Put(vegetableDetails);
            }
            catch (DbUpdateConcurrencyException)
            {
                return NotFound();
            }
            return NoContent();
        }
        [HttpDelete]
        public async Task<ActionResult> DeleteRecord(int id)
        {
            await _vegetableRepository.Delete(id);
            return NoContent();
        }


    }
}

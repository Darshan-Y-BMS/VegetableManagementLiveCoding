using Microsoft.EntityFrameworkCore;
using VegetableManagement.Components;
using VegetableManagement.Repositries;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<VegetableContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("VegetableConnection")));
builder.Services.AddScoped<IVegetable,VegetableDetailsRepository>();

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.Run();

﻿using System.ComponentModel.DataAnnotations;

namespace VegetableManagement.Components
{
    public class VendorDetails
    {
        [Key]public int VendorID { get; set; }
        public string VegetableID { get; set; }
        public string VendorName { get; set; }
        public string Place { get; set; }
    }
}

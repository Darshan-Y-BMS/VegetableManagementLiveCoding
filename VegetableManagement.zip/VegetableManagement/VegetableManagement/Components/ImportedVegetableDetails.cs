﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace VegetableManagement.Components
{
    public class ImportedVegetableDetails
    {
        [Key]public int VegetableID { get; set; }
        public string VegetableName { get; set; }
        public string VegetableCountry { get; set; }
    }
}

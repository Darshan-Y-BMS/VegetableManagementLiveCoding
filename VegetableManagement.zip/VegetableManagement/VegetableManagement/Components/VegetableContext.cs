﻿using Microsoft.EntityFrameworkCore;

namespace VegetableManagement.Components
{
    public class VegetableContext : DbContext
    {
        public VegetableContext(DbContextOptions<VegetableContext> options):base(options)
        {
            
        }

        public DbSet<VegetableDetails>? VegetableDetails { get; set; }   
        public DbSet<VendorDetails> VendorDetails { get; set; }
        public DbSet<ImportedVegetableDetails> ImportedVegetableDetails { get;set; }

    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace VegetableManagement.Components
{
    public class VegetableDetails
    {
      [Key]  public int VegetableID { get; set; }
        public string VegetableName { get; set; }
        public string VegetableColor { get; set; }


    }
}

﻿using VegetableManagement.Components;

namespace VegetableManagement.Repositries
{
    public interface IVegetable
    {
        Task<IEnumerable<VegetableDetails>> GetAll();
        Task<VegetableDetails> GetByID(int id);
        Task Post(VegetableDetails vegetableDetails);
        Task Delete(int id);
        Task Put(VegetableDetails vegetableDetails);
    }
}

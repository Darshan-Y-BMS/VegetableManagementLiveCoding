﻿using Microsoft.EntityFrameworkCore;
using VegetableManagement.Components;

namespace VegetableManagement.Repositries
{
    public class VegetableDetailsRepository : IVegetable
    {
        private readonly VegetableContext _dbContext;
        public VegetableDetailsRepository(VegetableContext dbContext)
        {
            _dbContext = dbContext;
        }
        public async Task Delete(int id)
        {
             var  temp = _dbContext.VegetableDetails.Find(id);
            if (temp != null)
            {
            _dbContext.VegetableDetails.Remove(temp);

            }
            await _dbContext.SaveChangesAsync();
        }

        public async Task<IEnumerable<VegetableDetails>> GetAll()
        {
            return await _dbContext.VegetableDetails.ToListAsync();
        }

        public async Task<VegetableDetails> GetByID(int id)
        {
            var temp = await _dbContext.VegetableDetails.FindAsync(id);
            if (temp == null) { }
            return temp;
        }

        public async Task Post(VegetableDetails vegetableDetails)
        {
             _dbContext.VegetableDetails.Add(vegetableDetails);
            await _dbContext.SaveChangesAsync();
         
        }
        public async Task Put(VegetableDetails vegetableDetails)
        {
             _dbContext.Entry(vegetableDetails).State = EntityState.Modified;
            await _dbContext.SaveChangesAsync();
        }
    }
}
